import { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { MaterialsCatalog } from "@/components/materials/catalog"

export const metadata: Metadata = {
  title: "Материалы для домашнего обучения — Без Барьера",
  description: "Карточки, игры, рабочие тетради и печатные материалы для изучения английского дома. Скачайте и начните заниматься сразу.",
  keywords: "английский для детей материалы, карточки английский, игры английский для детей, рабочие тетради английский",
}

export default function MaterialsPage() {
  return (
    <>
      <Header />
      <main className="pt-20">
        <MaterialsCatalog />
      </main>
      <Footer />
    </>
  )
}
