"use client"

import { Heart, MessageCircle, Sparkles, Shield } from "lucide-react"

const features = [
  {
    icon: Heart,
    title: "Комфорт ребёнка",
    description: "Создаём пространство, где ребёнок чувствует себя в безопасности и может раскрыться."
  },
  {
    icon: MessageCircle,
    title: "Живое общение",
    description: "Учим говорить, а не зубрить. Каждое занятие — это разговор, игра и открытие."
  },
  {
    icon: Sparkles,
    title: "Уверенность в себе",
    description: "Помогаем преодолеть страх ошибок и научиться выражать мысли свободно."
  },
  {
    icon: Shield,
    title: "Бережный подход",
    description: "Учитываем особенности каждого ребёнка. Не давим, не торопим, поддерживаем."
  }
]

export function AboutSection() {
  return (
    <section id="about" className="py-20 lg:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div>
              <span className="text-sm font-medium text-accent uppercase tracking-wider">
                О мастерской
              </span>
              <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance">
                Место, где английский становится родным
              </h2>
            </div>
            
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                <span className="font-semibold text-foreground">«Без Барьера»</span> — это языковая мастерская 
                для детей, где мы учим английскому через живое общение, игру и творчество.
              </p>
              <p>
                Мы верим, что каждый ребёнок может заговорить на английском свободно и с удовольствием. 
                Главное — создать правильную атмосферу: безопасную, тёплую, без страха ошибиться.
              </p>
              <p>
                Наши занятия — это не скучные уроки по учебнику. Это настоящее погружение в язык: 
                дети общаются, играют, творят и незаметно для себя начинают думать на английском.
              </p>
            </div>
          </div>
          
          {/* Features grid */}
          <div className="grid sm:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div 
                key={index}
                className="p-6 bg-background rounded-2xl border border-border hover:border-accent/50 hover:shadow-lg transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
