"use client"

import { useState } from "react"
import Link from "next/link"
import { MapPin, Phone, Mail, Clock, Send, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export function ContactSection() {
  const [formState, setFormState] = useState({
    name: "",
    phone: "",
    childAge: "",
    message: ""
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <section id="contact" className="py-20 lg:py-32 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <span className="text-sm font-medium text-accent uppercase tracking-wider">
                Контакты
              </span>
              <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight text-balance">
                Приходите знакомиться
              </h2>
              <p className="mt-6 text-lg text-primary-foreground/80 leading-relaxed">
                Запишитесь на бесплатное пробное занятие или просто загляните к нам. 
                Мы покажем мастерскую и ответим на все вопросы.
              </p>
            </div>
            
            {/* Contact details */}
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary-foreground/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Адрес</p>
                  <p className="text-primary-foreground/80">
                    Москва, проспект Дежнёва, 30
                  </p>
                  <p className="text-sm text-primary-foreground/60 mt-1">
                    5 минут от метро Бабушкинская
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary-foreground/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Телефон</p>
                  <a 
                    href="tel:+74951234567" 
                    className="text-primary-foreground/80 hover:text-primary-foreground transition-colors"
                  >
                    +7 (495) 123-45-67
                  </a>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary-foreground/10 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Режим работы</p>
                  <p className="text-primary-foreground/80">
                    Пн-Пт: 10:00 — 20:00
                  </p>
                  <p className="text-primary-foreground/80">
                    Сб: 10:00 — 18:00
                  </p>
                </div>
              </div>
            </div>
            
            {/* Social links */}
            <div className="space-y-4">
              <p className="font-semibold">Мы в социальных сетях</p>
              <div className="flex flex-wrap gap-3">
                <Link 
                  href="https://yandex.ru/maps/-/ABCDEF"
                  target="_blank"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-primary-foreground/10 rounded-full hover:bg-primary-foreground/20 transition-colors text-sm"
                >
                  <MapPin className="w-4 h-4" />
                  Яндекс Карты
                  <ExternalLink className="w-3 h-3" />
                </Link>
                <Link 
                  href="https://vk.com/bezbariera"
                  target="_blank"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-primary-foreground/10 rounded-full hover:bg-primary-foreground/20 transition-colors text-sm"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.864-.525-2.05-1.727-1.033-1-1.49-1.135-1.744-1.135-.356 0-.458.102-.458.593v1.575c0 .424-.135.678-1.253.678-1.846 0-3.896-1.118-5.335-3.202C4.624 10.857 4.03 8.57 4.03 8.096c0-.254.102-.491.593-.491h1.744c.44 0 .61.203.78.677.863 2.49 2.303 4.675 2.896 4.675.22 0 .322-.102.322-.66V9.721c-.068-1.186-.695-1.287-.695-1.71 0-.204.17-.407.44-.407h2.744c.373 0 .508.203.508.643v3.473c0 .372.17.508.271.508.22 0 .407-.136.813-.542 1.254-1.406 2.151-3.574 2.151-3.574.119-.254.322-.491.763-.491h1.744c.525 0 .644.27.525.643-.22 1.017-2.354 4.031-2.354 4.031-.186.305-.254.44 0 .78.186.254.796.779 1.203 1.253.745.847 1.32 1.558 1.473 2.05.17.49-.085.744-.576.744z"/>
                  </svg>
                  VK
                  <ExternalLink className="w-3 h-3" />
                </Link>
                <Link 
                  href="https://t.me/bezbariera"
                  target="_blank"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-primary-foreground/10 rounded-full hover:bg-primary-foreground/20 transition-colors text-sm"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                  </svg>
                  Telegram
                  <ExternalLink className="w-3 h-3" />
                </Link>
              </div>
            </div>
            
            {/* Map placeholder */}
            <div className="aspect-video bg-primary-foreground/10 rounded-2xl overflow-hidden">
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 mx-auto mb-3 text-primary-foreground/50" />
                  <p className="text-primary-foreground/60">Карта загружается...</p>
                  <Link 
                    href="https://yandex.ru/maps/-/ABCDEF"
                    target="_blank"
                    className="text-sm text-accent hover:underline mt-2 inline-block"
                  >
                    Открыть в Яндекс Картах
                  </Link>
                </div>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div className="bg-card text-card-foreground p-8 lg:p-10 rounded-3xl">
            <h3 className="font-serif text-2xl font-semibold mb-2">
              Записаться на пробное занятие
            </h3>
            <p className="text-muted-foreground mb-8">
              Оставьте заявку, и мы свяжемся с вами в течение часа
            </p>
            
            {isSubmitted ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-accent/20 flex items-center justify-center">
                  <Send className="w-8 h-8 text-primary" />
                </div>
                <h4 className="font-serif text-xl font-semibold text-foreground mb-2">
                  Заявка отправлена!
                </h4>
                <p className="text-muted-foreground">
                  Мы свяжемся с вами в ближайшее время, чтобы подобрать удобное время для пробного занятия.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium text-foreground">
                    Ваше имя
                  </label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Как вас зовут?"
                    value={formState.name}
                    onChange={(e) => setFormState({...formState, name: e.target.value})}
                    required
                    className="h-12 bg-background border-border"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-sm font-medium text-foreground">
                    Телефон
                  </label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+7 (___) ___-__-__"
                    value={formState.phone}
                    onChange={(e) => setFormState({...formState, phone: e.target.value})}
                    required
                    className="h-12 bg-background border-border"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="childAge" className="text-sm font-medium text-foreground">
                    Возраст ребёнка
                  </label>
                  <Input
                    id="childAge"
                    type="text"
                    placeholder="Сколько лет ребёнку?"
                    value={formState.childAge}
                    onChange={(e) => setFormState({...formState, childAge: e.target.value})}
                    required
                    className="h-12 bg-background border-border"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium text-foreground">
                    Комментарий <span className="text-muted-foreground">(необязательно)</span>
                  </label>
                  <Textarea
                    id="message"
                    placeholder="Расскажите о вашем ребёнке или задайте вопрос"
                    value={formState.message}
                    onChange={(e) => setFormState({...formState, message: e.target.value})}
                    className="min-h-24 bg-background border-border resize-none"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  size="lg"
                  disabled={isSubmitting}
                  className="w-full h-14 bg-primary hover:bg-primary/90 text-primary-foreground text-base"
                >
                  {isSubmitting ? "Отправляем..." : "Отправить заявку"}
                </Button>
                
                <p className="text-xs text-muted-foreground text-center">
                  Нажимая кнопку, вы соглашаетесь с{" "}
                  <Link href="/privacy" className="underline hover:text-foreground">
                    политикой конфиденциальности
                  </Link>
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
