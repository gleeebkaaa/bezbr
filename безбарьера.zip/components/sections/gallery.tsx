"use client"

const galleryImages = [
  {
    alt: "Уютный класс для занятий",
    description: "Светлое пространство"
  },
  {
    alt: "Групповое занятие",
    description: "Работа в группе"
  },
  {
    alt: "Игровая зона",
    description: "Зона для игр"
  },
  {
    alt: "Творческое занятие",
    description: "Творческий уголок"
  },
  {
    alt: "Материалы для занятий",
    description: "Наши материалы"
  },
  {
    alt: "Уголок чтения",
    description: "Библиотека"
  }
]

export function GallerySection() {
  return (
    <section className="py-20 lg:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-medium text-accent uppercase tracking-wider">
            Наше пространство
          </span>
          <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance">
            Загляните к нам
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Мы создали уютное пространство, где дети чувствуют себя как дома. 
            Светлые классы, удобная мебель, много игр и книг.
          </p>
        </div>
        
        {/* Gallery grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-6">
          {galleryImages.map((image, index) => (
            <div 
              key={index}
              className={`relative overflow-hidden rounded-2xl bg-secondary group cursor-pointer ${
                index === 0 ? "md:col-span-2 md:row-span-2" : ""
              }`}
            >
              <div className={`${index === 0 ? "aspect-square md:aspect-auto md:h-full" : "aspect-square"} bg-gradient-to-br from-accent/20 via-secondary to-primary/10 flex items-center justify-center`}>
                <div className="text-center p-4">
                  <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-card/50 flex items-center justify-center">
                    <span className="text-2xl font-serif text-primary">{index + 1}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{image.description}</p>
                </div>
              </div>
              
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-primary/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <p className="text-primary-foreground font-medium text-center px-4">
                  {image.alt}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
