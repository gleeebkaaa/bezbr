"use client"

import Link from "next/link"
import { Check, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const pricingPlans = [
  {
    title: "Пробное занятие",
    price: "Бесплатно",
    priceNote: "первое занятие",
    description: "Познакомьтесь с мастерской и нашим подходом",
    features: [
      "Знакомство с преподавателем",
      "Оценка уровня ребёнка",
      "Подбор программы",
      "Ответы на все вопросы"
    ],
    cta: "Записаться",
    popular: false
  },
  {
    title: "Абонемент на месяц",
    price: "8 000 ₽",
    priceNote: "8 занятий",
    description: "Оптимальный вариант для регулярных занятий",
    features: [
      "2 занятия в неделю",
      "Доступ к материалам",
      "Обратная связь родителям",
      "Участие в мероприятиях"
    ],
    cta: "Выбрать",
    popular: true
  },
  {
    title: "Индивидуальные занятия",
    price: "2 500 ₽",
    priceNote: "за занятие",
    description: "Персональный подход для максимального результата",
    features: [
      "Индивидуальная программа",
      "Гибкое расписание",
      "Полное внимание ребёнку",
      "Ускоренный прогресс"
    ],
    cta: "Записаться",
    popular: false
  }
]

export function PricesSection() {
  return (
    <section id="prices" className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-medium text-accent uppercase tracking-wider">
            Стоимость занятий
          </span>
          <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance">
            Прозрачные цены без скрытых платежей
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Выберите подходящий формат обучения. Первое занятие всегда бесплатное — 
            приходите познакомиться.
          </p>
        </div>
        
        {/* Pricing cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <div 
              key={index}
              className={`relative bg-card rounded-3xl border overflow-hidden transition-all duration-300 hover:shadow-xl ${
                plan.popular 
                  ? "border-accent shadow-lg scale-105 lg:scale-110" 
                  : "border-border"
              }`}
            >
              {/* Popular badge */}
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 bg-accent text-center py-2">
                  <span className="text-sm font-medium text-foreground">Популярный выбор</span>
                </div>
              )}
              
              <div className={`p-8 ${plan.popular ? "pt-14" : ""}`}>
                <h3 className="font-semibold text-xl text-foreground mb-2">
                  {plan.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-6">
                  {plan.description}
                </p>
                
                <div className="mb-6">
                  <span className="font-serif text-4xl font-semibold text-primary">
                    {plan.price}
                  </span>
                  <span className="text-muted-foreground ml-2">
                    / {plan.priceNote}
                  </span>
                </div>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-primary" />
                      </div>
                      <span className="text-sm text-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  asChild 
                  className={`w-full ${
                    plan.popular 
                      ? "bg-primary hover:bg-primary/90 text-primary-foreground" 
                      : "bg-secondary hover:bg-secondary/80 text-foreground"
                  }`}
                >
                  <Link href="#contact">
                    {plan.cta}
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        {/* Note */}
        <p className="text-center text-muted-foreground mt-12 max-w-2xl mx-auto">
          Возможна оплата материнским капиталом. Предоставляем документы для налогового вычета.
        </p>
      </div>
    </section>
  )
}
