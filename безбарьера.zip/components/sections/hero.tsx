"use client"

import Link from "next/link"
import { MapPin, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-secondary/30 to-background" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-0 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <div className="space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary rounded-full">
              <span className="w-2 h-2 bg-accent rounded-full" />
              <span className="text-sm font-medium text-foreground">Языковая мастерская для детей</span>
            </div>
            
            {/* Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-foreground leading-tight text-balance">
              Английский язык, 
              <span className="text-primary"> который ребёнок полюбит</span>
            </h1>
            
            {/* Subheadline */}
            <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed max-w-xl">
              Учим детей говорить по-английски свободно и с удовольствием. 
              Без страха ошибиться, без скучных учебников — через живое общение и игру.
            </p>
            
            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                asChild 
                size="lg" 
                className="bg-primary hover:bg-primary/90 text-primary-foreground text-base px-8 h-14"
              >
                <Link href="#contact">
                  Записаться на пробное занятие
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
              <Button 
                asChild 
                variant="outline" 
                size="lg"
                className="border-primary/30 text-foreground hover:bg-secondary text-base px-8 h-14"
              >
                <Link href="#materials">
                  Посмотреть материалы
                </Link>
              </Button>
            </div>
            
            {/* Location */}
            <div className="flex flex-wrap items-center gap-6 pt-4">
              <Link 
                href="#contact" 
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <MapPin className="w-5 h-5 text-accent" />
                <span>Москва, пр. Дежнёва, 30</span>
              </Link>
              
              <div className="flex items-center gap-4">
                <Link 
                  href="https://t.me/bezbariera" 
                  target="_blank"
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-secondary hover:bg-accent/20 transition-colors"
                  aria-label="Telegram"
                >
                  <svg className="w-5 h-5 text-foreground" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                  </svg>
                </Link>
                <Link 
                  href="https://vk.com/bezbariera" 
                  target="_blank"
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-secondary hover:bg-accent/20 transition-colors"
                  aria-label="VK"
                >
                  <svg className="w-5 h-5 text-foreground" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.864-.525-2.05-1.727-1.033-1-1.49-1.135-1.744-1.135-.356 0-.458.102-.458.593v1.575c0 .424-.135.678-1.253.678-1.846 0-3.896-1.118-5.335-3.202C4.624 10.857 4.03 8.57 4.03 8.096c0-.254.102-.491.593-.491h1.744c.44 0 .61.203.78.677.863 2.49 2.303 4.675 2.896 4.675.22 0 .322-.102.322-.66V9.721c-.068-1.186-.695-1.287-.695-1.71 0-.204.17-.407.44-.407h2.744c.373 0 .508.203.508.643v3.473c0 .372.17.508.271.508.22 0 .407-.136.813-.542 1.254-1.406 2.151-3.574 2.151-3.574.119-.254.322-.491.763-.491h1.744c.525 0 .644.27.525.643-.22 1.017-2.354 4.031-2.354 4.031-.186.305-.254.44 0 .78.186.254.796.779 1.203 1.253.745.847 1.32 1.558 1.473 2.05.17.49-.085.744-.576.744z"/>
                  </svg>
                </Link>
              </div>
            </div>
          </div>
          
          {/* Hero Image/Illustration area */}
          <div className="relative">
            <div className="aspect-[4/3] bg-gradient-to-br from-secondary via-accent/20 to-secondary rounded-3xl overflow-hidden shadow-2xl shadow-primary/10">
              {/* Placeholder for hero image - warm, inviting classroom scene */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-accent/30 flex items-center justify-center">
                    <span className="text-4xl font-serif text-primary">ББ</span>
                  </div>
                  <p className="text-lg text-muted-foreground font-medium">
                    Уютная атмосфера для обучения
                  </p>
                </div>
              </div>
            </div>
            
            {/* Floating stats card */}
            <div className="absolute -bottom-6 -left-6 bg-card p-6 rounded-2xl shadow-xl border border-border">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                  <span className="text-xl font-serif font-semibold text-primary">5+</span>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">лет опыта</p>
                  <p className="font-medium text-foreground">работы с детьми</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
