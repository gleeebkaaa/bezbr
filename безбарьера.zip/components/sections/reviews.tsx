"use client"

import { Star, Quote } from "lucide-react"

const reviews = [
  {
    name: "Анна М.",
    child: "мама Миши, 7 лет",
    text: "Сын ходит уже полгода и результаты потрясающие! Он сам просит идти на занятия, а дома начал смотреть мультики на английском. Атмосфера в мастерской очень тёплая, ребёнок чувствует себя комфортно.",
    rating: 5
  },
  {
    name: "Екатерина В.",
    child: "мама Софии, 5 лет",
    text: "Долго искали подходящее место для дочки и очень рады, что нашли «Без Барьера». Педагог находит подход к каждому ребёнку, занятия проходят в игровой форме. София с удовольствием учит новые слова.",
    rating: 5
  },
  {
    name: "Дмитрий К.",
    child: "папа Артёма, 10 лет",
    text: "Отличная мастерская! Сын раньше боялся говорить на английском, а теперь свободно общается. Преподаватели умеют заинтересовать и поддержать. Рекомендую всем родителям.",
    rating: 5
  },
  {
    name: "Ольга С.",
    child: "мама Алисы, 8 лет",
    text: "Удобное расположение, приятный интерьер, а главное — профессиональный подход. Дочь за три месяца сильно продвинулась, стала увереннее. Спасибо команде мастерской!",
    rating: 5
  }
]

export function ReviewsSection() {
  return (
    <section id="reviews" className="py-20 lg:py-32 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-medium text-accent uppercase tracking-wider">
            Отзывы родителей
          </span>
          <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance">
            Что говорят о нас
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Отзывы родителей — лучшее подтверждение нашей работы. 
            Мы гордимся каждым довольным учеником.
          </p>
        </div>
        
        {/* Reviews grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {reviews.map((review, index) => (
            <div 
              key={index}
              className="bg-card p-8 rounded-3xl border border-border hover:shadow-lg transition-all duration-300"
            >
              {/* Quote icon */}
              <div className="mb-6">
                <Quote className="w-10 h-10 text-accent/50" />
              </div>
              
              {/* Review text */}
              <p className="text-foreground leading-relaxed mb-6">
                {review.text}
              </p>
              
              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-accent text-accent" />
                ))}
              </div>
              
              {/* Author */}
              <div>
                <p className="font-semibold text-foreground">{review.name}</p>
                <p className="text-sm text-muted-foreground">{review.child}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
