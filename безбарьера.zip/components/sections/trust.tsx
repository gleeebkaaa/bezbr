"use client"

import { Check, MapPin, Award, Users, TrendingUp, Heart } from "lucide-react"

const advantages = [
  {
    icon: Heart,
    title: "Тёплая атмосфера",
    description: "Ребёнок чувствует себя комфортно и раскрывается на занятиях"
  },
  {
    icon: TrendingUp,
    title: "Фокус на разговорной речи",
    description: "80% времени занятия — живая практика и общение на английском"
  },
  {
    icon: Award,
    title: "Видимый прогресс",
    description: "Родители видят результаты уже после первых занятий"
  },
  {
    icon: Users,
    title: "Маленькие группы",
    description: "До 8 детей в группе — внимание каждому ребёнку"
  },
  {
    icon: MapPin,
    title: "Удобное расположение",
    description: "В шаговой доступности от метро, рядом с домом"
  },
  {
    icon: Check,
    title: "Гибкое расписание",
    description: "Подберём удобное время для занятий вашего ребёнка"
  }
]

export function TrustSection() {
  return (
    <section className="py-20 lg:py-32 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-medium text-accent uppercase tracking-wider">
            Почему выбирают нас
          </span>
          <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance">
            Доверие родителей — наша главная ценность
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Мы создаём условия, в которых дети учатся с удовольствием, 
            а родители спокойны за результат.
          </p>
        </div>
        
        {/* Advantages grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {advantages.map((advantage, index) => (
            <div 
              key={index}
              className="flex gap-4 p-6 bg-card rounded-2xl border border-border hover:border-accent/50 hover:shadow-md transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center flex-shrink-0">
                <advantage.icon className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-foreground mb-2">
                  {advantage.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {advantage.description}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { value: "5+", label: "лет работы" },
            { value: "200+", label: "учеников" },
            { value: "95%", label: "довольных родителей" },
            { value: "8", label: "человек в группе макс." }
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="font-serif text-4xl lg:text-5xl font-semibold text-primary">
                {stat.value}
              </div>
              <div className="mt-2 text-muted-foreground">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
