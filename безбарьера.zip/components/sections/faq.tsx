"use client"

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const faqs = [
  {
    question: "С какого возраста можно начинать занятия?",
    answer: "Мы принимаем детей с 4 лет. В этом возрасте дети уже готовы к групповым занятиям и легко усваивают новый язык через игру и общение. Для самых маленьких у нас есть специальная программа «Первые шаги» с короткими занятиями по 45 минут."
  },
  {
    question: "Как проходит пробное занятие?",
    answer: "Пробное занятие бесплатное и длится столько же, сколько обычное. Ребёнок присоединяется к группе своего возраста и участвует в полноценном занятии. После мы обсуждаем с родителями впечатления, отвечаем на вопросы и подбираем оптимальную программу."
  },
  {
    question: "Сколько детей в группе?",
    answer: "В наших группах не более 8 детей. Это позволяет уделить внимание каждому ребёнку, при этом сохранить возможность для групповой работы и общения между детьми. Для младших групп (4-6 лет) максимум 6 детей."
  },
  {
    question: "Нужно ли ребёнку уже знать английский?",
    answer: "Нет, мы работаем с детьми любого уровня — от нуля до продвинутого. Перед началом занятий мы определяем текущий уровень и подбираем подходящую группу. Если ребёнок только начинает, он попадёт в группу с такими же начинающими."
  },
  {
    question: "Какие материалы нужны для занятий?",
    answer: "Все основные материалы предоставляем мы. Для домашней работы рекомендуем наши рабочие тетради и карточки, которые можно приобрести в разделе «Материалы». Это не обязательно, но помогает закрепить результат."
  },
  {
    question: "Можно ли перенести или отменить занятие?",
    answer: "Да, если предупредить за 24 часа. Пропущенное занятие можно отработать с другой группой того же уровня в течение месяца. Мы понимаем, что жизнь непредсказуема, и стараемся идти навстречу."
  },
  {
    question: "Как отслеживать прогресс ребёнка?",
    answer: "Мы регулярно даём обратную связь родителям: рассказываем о успехах, рекомендуем, на что обратить внимание дома. Каждые 3 месяца проводим мини-тестирование и обсуждаем результаты с родителями."
  },
  {
    question: "Есть ли подготовка к экзаменам?",
    answer: "Да, для детей 11-14 лет у нас есть программа подготовки к международным экзаменам (Cambridge YLE, KET, PET). Также готовим к школьным олимпиадам и ВПР по английскому языку."
  }
]

export function FAQSection() {
  return (
    <section id="faq" className="py-20 lg:py-32 bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-sm font-medium text-accent uppercase tracking-wider">
            Частые вопросы
          </span>
          <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance">
            Ответы на ваши вопросы
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
            Собрали самые частые вопросы от родителей. 
            Если не нашли ответ — напишите нам, мы с радостью поможем.
          </p>
        </div>
        
        {/* FAQ Accordion */}
        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem 
              key={index} 
              value={`item-${index}`}
              className="bg-card border border-border rounded-2xl px-6 data-[state=open]:shadow-md transition-all"
            >
              <AccordionTrigger className="text-left font-semibold text-foreground hover:no-underline py-6">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed pb-6">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}
