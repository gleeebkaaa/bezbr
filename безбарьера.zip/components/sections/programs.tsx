"use client"

import Link from "next/link"
import { ArrowRight, Users, Clock, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"

const programs = [
  {
    age: "4-6 лет",
    title: "Первые шаги",
    description: "Знакомство с английским через песни, игры и творчество. Формируем любовь к языку с самого начала.",
    features: [
      "Игровой формат занятий",
      "Развитие слухового восприятия",
      "Базовая лексика через песни",
      "Творческие активности"
    ],
    duration: "45 минут",
    groupSize: "до 6 детей",
    color: "bg-accent/20"
  },
  {
    age: "7-10 лет",
    title: "Уверенное общение",
    description: "Развиваем разговорные навыки, учим выражать свои мысли. Грамматика через практику, не зубрёжку.",
    features: [
      "Разговорная практика",
      "Чтение и понимание текстов",
      "Грамматика в контексте",
      "Проектная работа"
    ],
    duration: "60 минут",
    groupSize: "до 8 детей",
    color: "bg-primary/10"
  },
  {
    age: "11-14 лет",
    title: "Свободное владение",
    description: "Углублённое изучение языка, подготовка к экзаменам. Обсуждаем интересные темы, развиваем критическое мышление.",
    features: [
      "Дискуссии на английском",
      "Письменная речь",
      "Подготовка к экзаменам",
      "Работа с аутентичными материалами"
    ],
    duration: "90 минут",
    groupSize: "до 8 детей",
    color: "bg-secondary"
  }
]

export function ProgramsSection() {
  return (
    <section id="programs" className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-medium text-accent uppercase tracking-wider">
            Программы обучения
          </span>
          <h2 className="mt-4 font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance">
            Занятия для каждого возраста
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Мы разработали программы, которые учитывают особенности каждого возраста. 
            От первого знакомства с языком до свободного владения.
          </p>
        </div>
        
        {/* Programs grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {programs.map((program, index) => (
            <div 
              key={index}
              className="relative bg-card rounded-3xl border border-border overflow-hidden hover:shadow-xl transition-all duration-300 group"
            >
              {/* Header */}
              <div className={`${program.color} p-6 pb-8`}>
                <span className="inline-block px-3 py-1 bg-card/80 rounded-full text-sm font-medium text-foreground mb-4">
                  {program.age}
                </span>
                <h3 className="font-serif text-2xl font-semibold text-foreground">
                  {program.title}
                </h3>
              </div>
              
              {/* Content */}
              <div className="p-6 space-y-6">
                <p className="text-muted-foreground leading-relaxed">
                  {program.description}
                </p>
                
                {/* Features */}
                <ul className="space-y-3">
                  {program.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0" />
                      <span className="text-sm text-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                {/* Meta info */}
                <div className="flex items-center gap-4 pt-4 border-t border-border">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>{program.duration}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="w-4 h-4" />
                    <span>{program.groupSize}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* CTA */}
        <div className="text-center mt-12">
          <Button 
            asChild 
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Link href="#contact">
              Записаться на пробное занятие
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
