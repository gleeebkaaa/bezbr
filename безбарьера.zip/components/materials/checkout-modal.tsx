"use client"

import { useState } from "react"
import { X, CreditCard, Check, Download, Mail, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { type Material } from "@/lib/materials-data"

type CheckoutModalProps = {
  material: Material
  isOpen: boolean
  onClose: () => void
}

type CheckoutStep = "info" | "payment" | "success"

export function CheckoutModal({ material, isOpen, onClose }: CheckoutModalProps) {
  const [step, setStep] = useState<CheckoutStep>("info")
  const [isProcessing, setIsProcessing] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
  })
  
  if (!isOpen) return null
  
  const handleInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setStep("payment")
  }
  
  const handlePayment = async () => {
    setIsProcessing(true)
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000))
    setIsProcessing(false)
    setStep("success")
  }
  
  const handleClose = () => {
    setStep("info")
    setFormData({ name: "", email: "" })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-foreground/50 backdrop-blur-sm"
        onClick={handleClose}
      />
      
      {/* Modal */}
      <div className="relative bg-card rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden">
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors z-10"
          aria-label="Закрыть"
        >
          <X className="w-5 h-5 text-foreground" />
        </button>
        
        {/* Step: Customer Info */}
        {step === "info" && (
          <div className="p-8">
            <h2 className="font-serif text-2xl font-semibold text-foreground mb-2">
              Оформление заказа
            </h2>
            <p className="text-muted-foreground mb-8">
              Введите данные для получения материалов
            </p>
            
            {/* Product summary */}
            <div className="bg-secondary/50 rounded-2xl p-4 mb-8 flex items-center gap-4">
              <div className="w-16 h-16 rounded-xl bg-accent/20 flex items-center justify-center flex-shrink-0">
                <Download className="w-8 h-8 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-foreground truncate">
                  {material.title}
                </p>
                <p className="text-sm text-muted-foreground">
                  {material.format} • {material.pages} стр.
                </p>
              </div>
              <div className="font-serif text-xl font-semibold text-primary">
                {material.price} ₽
              </div>
            </div>
            
            <form onSubmit={handleInfoSubmit} className="space-y-5">
              <div className="space-y-2">
                <label htmlFor="checkout-name" className="text-sm font-medium text-foreground">
                  Ваше имя
                </label>
                <Input
                  id="checkout-name"
                  type="text"
                  placeholder="Как вас зовут?"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  className="h-12 bg-background border-border"
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="checkout-email" className="text-sm font-medium text-foreground">
                  Email для получения материалов
                </label>
                <Input
                  id="checkout-email"
                  type="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                  className="h-12 bg-background border-border"
                />
                <p className="text-xs text-muted-foreground">
                  На этот адрес придёт ссылка для скачивания
                </p>
              </div>
              
              <Button 
                type="submit" 
                size="lg"
                className="w-full h-14 bg-primary hover:bg-primary/90 text-primary-foreground text-base mt-4"
              >
                Перейти к оплате
              </Button>
            </form>
          </div>
        )}
        
        {/* Step: Payment */}
        {step === "payment" && (
          <div className="p-8">
            <h2 className="font-serif text-2xl font-semibold text-foreground mb-2">
              Оплата
            </h2>
            <p className="text-muted-foreground mb-8">
              Безопасная оплата банковской картой
            </p>
            
            {/* Order summary */}
            <div className="bg-secondary/50 rounded-2xl p-4 mb-8">
              <div className="flex justify-between items-center mb-3">
                <span className="text-foreground">{material.title}</span>
                <span className="font-semibold text-foreground">{material.price} ₽</span>
              </div>
              <div className="flex justify-between items-center pt-3 border-t border-border">
                <span className="font-semibold text-foreground">Итого к оплате</span>
                <span className="font-serif text-xl font-semibold text-primary">{material.price} ₽</span>
              </div>
            </div>
            
            {/* Simulated payment form */}
            <div className="space-y-5 mb-8">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  Номер карты
                </label>
                <Input
                  type="text"
                  placeholder="0000 0000 0000 0000"
                  className="h-12 bg-background border-border"
                  defaultValue="4242 4242 4242 4242"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Срок действия
                  </label>
                  <Input
                    type="text"
                    placeholder="MM/YY"
                    className="h-12 bg-background border-border"
                    defaultValue="12/28"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    CVV
                  </label>
                  <Input
                    type="text"
                    placeholder="***"
                    className="h-12 bg-background border-border"
                    defaultValue="123"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Button 
                variant="outline"
                size="lg"
                onClick={() => setStep("info")}
                className="flex-1 h-14 border-border"
              >
                Назад
              </Button>
              <Button 
                size="lg"
                onClick={handlePayment}
                disabled={isProcessing}
                className="flex-1 h-14 bg-primary hover:bg-primary/90 text-primary-foreground text-base"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Обработка...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-5 h-5 mr-2" />
                    Оплатить {material.price} ₽
                  </>
                )}
              </Button>
            </div>
            
            <p className="text-xs text-muted-foreground text-center mt-4">
              Платёж защищён 256-битным шифрованием
            </p>
          </div>
        )}
        
        {/* Step: Success */}
        {step === "success" && (
          <div className="p-8 text-center">
            <div className="w-20 h-20 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-primary" />
            </div>
            
            <h2 className="font-serif text-2xl font-semibold text-foreground mb-2">
              Оплата прошла успешно!
            </h2>
            <p className="text-muted-foreground mb-8">
              Ссылка для скачивания отправлена на {formData.email}
            </p>
            
            <div className="bg-secondary/50 rounded-2xl p-6 mb-8 text-left">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground mb-1">
                    Проверьте почту
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Мы отправили письмо со ссылкой для скачивания. 
                    Если письмо не пришло, проверьте папку «Спам».
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <Button 
                size="lg"
                className="w-full h-14 bg-primary hover:bg-primary/90 text-primary-foreground text-base"
              >
                <Download className="w-5 h-5 mr-2" />
                Скачать материалы
              </Button>
              <Button 
                variant="outline"
                size="lg"
                onClick={handleClose}
                className="w-full h-14 border-border"
              >
                Вернуться в каталог
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
